import { Component } from "@angular/core";
@Component({
    selector: "store-movies",
    templateUrl: "movieSelection.component.html"
})
export class MovieSelectionComponent {
}
